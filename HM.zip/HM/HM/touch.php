<html>
<body>
<?php	exec('python autosched.py');
	header( "Location: http://localhost/HMS6/pyAutoSched.php" );
?>
</body>
</html>
